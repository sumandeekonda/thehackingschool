

// var links = document.getElementsByTagName('a');
// for(var j = 0; j<links.length;j++){
//     links[j].href = "https://www.youtube.com/watch?v=9bZkp7q19f0";
// }

var images = document.getElementsByTagName('img');
for (var i = 0; i<images.length; i++) {
  images[i].src = "https://img.purch.com/w/660/aHR0cDovL3d3dy5saXZlc2NpZW5jZS5jb20vaW1hZ2VzL2kvMDAwLzA4OC85MTEvb3JpZ2luYWwvZ29sZGVuLXJldHJpZXZlci1wdXBweS5qcGVn";
}

